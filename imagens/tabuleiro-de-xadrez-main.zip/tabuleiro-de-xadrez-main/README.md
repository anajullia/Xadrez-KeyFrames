# tabuleiro-de-xadrez
A atividade é, fazer um tabuleiro de xadrez, onde terá apenas uma peça, o cavalo. Você deve animar o cavalo usando Key-Frame, fazendo o cavalo sair do "ponto A" para o "ponto B" e sair do "ponto B" e voltar para o "ponto A"
